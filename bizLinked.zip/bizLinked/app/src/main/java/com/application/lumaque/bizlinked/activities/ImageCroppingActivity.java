package com.application.lumaque.bizlinked.activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.application.lumaque.bizlinked.R;

public class ImageCroppingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_cropping);
    }
}
