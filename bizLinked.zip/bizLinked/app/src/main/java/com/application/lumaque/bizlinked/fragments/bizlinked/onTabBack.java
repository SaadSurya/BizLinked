package com.application.lumaque.bizlinked.fragments.bizlinked;


interface onTabBack {
    void doback();
}
