package com.application.lumaque.bizlinked.fragments.bizlinked;


import com.application.lumaque.bizlinked.data_models.bizlinked.ProductAttribute;

public interface TagCloseCallBack {


    void onImageClick(ProductAttribute productAttribute);
    void onRowClick(ProductAttribute productAttribute);


}
