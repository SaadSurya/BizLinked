package com.application.lumaque.bizlinked.listener;


import com.google.android.gms.maps.GoogleMap;

public interface MapReadyListener {
    public void onMapReady(GoogleMap googleMap);
}
