package com.application.lumaque.bizlinked.listener;


import android.content.Intent;

public interface OnActivityResultInterface {
    void onActivityResultInterface(int requestCode, int resultCode, Intent data);
}
