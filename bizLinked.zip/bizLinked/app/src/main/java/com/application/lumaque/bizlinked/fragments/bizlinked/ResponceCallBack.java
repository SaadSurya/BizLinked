package com.application.lumaque.bizlinked.fragments.bizlinked;

import com.application.lumaque.bizlinked.data_models.bizlinked.ProductCategory;

import java.util.ArrayList;

public interface ResponceCallBack {



    void onCategoryResponce(ArrayList<ProductCategory> categoryList);

}


