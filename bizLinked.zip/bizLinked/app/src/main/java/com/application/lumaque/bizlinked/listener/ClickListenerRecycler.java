package com.application.lumaque.bizlinked.listener;

import android.view.View;

public interface ClickListenerRecycler {
     void onClick(View view, int position);
     void onLongClick(View view, int position);
}
