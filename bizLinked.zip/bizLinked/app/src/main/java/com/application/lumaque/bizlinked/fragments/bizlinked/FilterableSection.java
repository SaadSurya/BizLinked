package com.application.lumaque.bizlinked.fragments.bizlinked;


interface FilterableSection {
    void filter(String query);
}
