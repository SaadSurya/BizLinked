package com.application.lumaque.bizlinked.listener;


public interface LocationListener {
    void onLocationReceived();

    void onNoLocationReceived();

    void onNoActionPerformed();
}
